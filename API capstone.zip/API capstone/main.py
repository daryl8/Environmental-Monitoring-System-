from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient

app = FastAPI()

# Connect to MongoDB
client = AsyncIOMotorClient("mongodb://localhost:27017")
db = client["sensor_data"]
collection = db["latest_sensor_data"]

# Define allowed origins
origins = [
    "http://localhost",
    "http://localhost:5500",
    "http://192.168.108.112:8000"  # Add your frontend origin here
]

# CORS middleware with allow origins parameter
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["GET", "POST"],  # Add any additional HTTP methods as needed
    allow_headers=["*"]
    
)

# Define route to receive sensor data
@app.post('/data')
async def receive_sensor_data(sensor_data: dict):
    try:
        # Store sensor data in MongoDB
        await collection.insert_one(sensor_data)
        print("Received sensor data:", sensor_data)
        return {'message': 'Sensor data received successfully'}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# Define route to get latest sensor data
@app.get('/sensor_data')
async def get_latest_sensor_data():
    try:
        # Retrieve the latest sensor data from MongoDB
        latest_data = await collection.find_one({}, sort=[("_id", -1)])

        if latest_data:
            # Convert MongoDB document to dictionary
            transformed_data = dict(latest_data)
            # Remove the "_id" key from the dictionary
            transformed_data.pop("_id", None)
            return transformed_data
        else:
            raise HTTPException(status_code=404, detail="No data available")
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


if __name__ == '__main__':
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000, reload=True)

