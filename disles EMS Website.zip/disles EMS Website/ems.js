// Function to fetch latest sensor data from the API
async function fetchSensorData() {
  try {
    const response = await fetch('http://192.168.108.112:8000/sensor_data');
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error fetching sensor data:', error);
  }
}

// Function to update input fields with sensor data and log alarms
async function updateSensorData() {
  const sensorData = await fetchSensorData();
  console.log('Received sensor data:', sensorData); // Log the received sensor data

  if (sensorData && sensorData.data) {
    const dataArr = sensorData.data.split(': ');
    const dataType = dataArr[0].trim().toLowerCase(); // Trim whitespace before converting to lowercase
    const dataValue = parseFloat(dataArr[1].trim()); // Trim whitespace before parsing as float

    let inputFieldId;
    let limit;
    let readingType;

    switch (dataType) {
      case 'temp':
        inputFieldId = 'temperature-input';
        limit = 30;
        readingType = 'Temperature';
        break;
      case 'humidity':
        inputFieldId = 'humidity-input';
        limit = 60;
        readingType = 'Humidity';
        break;
      case 'gas':
        inputFieldId = 'gas-input';
        limit = 50;
        readingType = 'Gas';
        break;
      case 'sound':
        inputFieldId = 'sound-input';
        limit = 125;
        readingType = 'Sound';
        break;
      default:
        break;
    }

    if (inputFieldId && !isNaN(dataValue)) {
      const inputField = document.getElementById(inputFieldId);
      if (inputField) {
        inputField.value = dataValue;
      }
      if (dataValue > limit) {
        logAlarm(readingType, dataValue);
      }
    }
  }
}

// Function to log alarms with date and time
function logAlarm(readingType, value) {
  const alarmLog = document.getElementById('alarm-log');
  const alarmEntry = document.createElement('div');
  const now = new Date();
  const dateTimeString = now.toLocaleString();
  let unit;

  switch (readingType) {
    case 'Temperature':
      unit = '°C';
      break;
    case 'Humidity':
      unit = '%';
      break;
    case 'Gas':
      unit = 'ppm';
      break;
    case 'Sound':
      unit = 'dB';
      break;
    default:
      unit = '';
      break;
  }

  alarmEntry.textContent = `${dateTimeString}: ${readingType} exceeded. Value: ${value} ${unit}`;
  alarmLog.appendChild(alarmEntry);
}

// Function to periodically update sensor data
async function refreshSensorData() {
  await updateSensorData();
  setInterval(updateSensorData, 5000); // Update every 5 seconds
}

// Call the refreshSensorData function when the page loads
window.onload = refreshSensorData;
